---
type: paper
tags: 📥️/📜️/💻/🕸
aliases:
  - 
cssclass: 
---



# Title: **[[Свойство background-color 2021-10-07]]]**
- `Type:` [[&]]
- `Links:`
- `Reviewed Date:` [[2021-10-07]]

  
Свойство `background-color` или просто `background` служит для изменения фона блока, таблицы, ячейки и прочего. Цвет можно задать по названию, шестнадцатеричным числом, RGB, RGBA, HSL и HSLA. Далее пример:

Пример 4, CSS

```css
td {    background: rgb(0, 0, 255);    color: #FFFFFF;    padding: 10px;}
```