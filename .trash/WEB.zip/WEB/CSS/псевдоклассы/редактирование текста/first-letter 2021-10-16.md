---
type: paper
tags: 📥️/📜️/💻/🕸
aliases:
  - 
cssclass: 
---



# Title: **[[first-letter 2021-10-16]]**
- `Type:` [[&]]
- `Links:`
- `Reviewed Date:` [[2021-10-16]]


## Первая буква

Меняет буквку первого абзаца 

```css
p:first-letter {  
	color: red;  
	font-size: 2em;  
}
```

[[first-letter.html|пример]]