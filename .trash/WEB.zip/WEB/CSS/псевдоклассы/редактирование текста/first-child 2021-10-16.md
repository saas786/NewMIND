---
type: paper
tags: 📥️/📜️/💻/🕸
aliases:
  - 
cssclass: 
---



# Title: **[[first-child 2021-10-16]]**
- `Type:` [[&]]
- `Links:`
- `Reviewed Date:` [[2021-10-16]]

# первый дочерний элемент
`first-child` – выбор первого дочернего элемента.


```css
b:first-child { color: green }
```

[[first-child.html|пример]]