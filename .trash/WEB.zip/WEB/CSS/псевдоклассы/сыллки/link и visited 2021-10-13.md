---
type: paper
tags: 📥️/📜️/💻/🕸
aliases:
  - 
cssclass: 
---



# Title: **[[link и visited 2021-10-13]]**
- `Type:` [[&]]
- `Links:`
- `Reviewed Date:` [[2021-10-13]]

# Псевдоклассы: ссылки

Существует всего два псевдокласса, которые применяются только к ссылкам – `link` и `visited`.

`:link` Если ссылка **не была** посещена.

`:visited` - Если ссылка **была** посещена.

```css
a {  
color: blue;  
}  
a:visited {  
color: black;  
}
```