---
type: paper
tags: 📥️/📜️/🩳/💻/🕸
aliases:
  - 
cssclass: 
---



# Title: **[[Атрибут accesskey 2021-10-05]]]**
- `Type:` [[&]]
- `Links:` [[HTML+CSS moc]]
- `Reviewed Date:` [[2021-10-05]]

## Атрибут accesskey

Благодаря этому атрибуту, появилась возможность обращаться к тегу при помощи сочетания клавиш. Но, для каждого браузера свое сочетание клавиш: `accesskey = "a"`, в Internet Explorer будет вызываться так: `alt + s + a`. Далее пример:

Код HTML

```html
<a accesskey = "c">ссылка</a>
```


<a accesskey = "c">ссылка</a>