---
type: paper
tags: 📥️/📜️/💻
aliases:
  - 
cssclass: 
---


- `Title:` [[& List of XML and HTML character entity references 2021-08-25]]
- `Type:` [[+]]
- `Tags:` 
- `URL:` [[]](https://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references)
- `Channel/Host:` 
- `Reference:` 
- `Publish Date:` 
- `Reviewed Date:` [[2021-08-25]]

---

<center><iframe width="1000" height="680" src="https://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

---